var fs = require('fs')

console.log(fs.readFile)
